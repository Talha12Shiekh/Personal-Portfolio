export const RED_COLOR = '#e97271';
export const WHITE_COLOR = '#fff';
export const GREEN_COLOR = '#7fff00';
export const DARK_GREEN_COLOR = '#427e04';
export const BLACK_COLOR = '#171717';
export const BG_COLOR = '#010101';

export const center = {
    alignItems:"center",
    justifyContent:"center"
}