import TodoList from './Components/TodoList'

const App = () => {
  return (
    <>
      <TodoList/>
    </>
  )
}

export default App